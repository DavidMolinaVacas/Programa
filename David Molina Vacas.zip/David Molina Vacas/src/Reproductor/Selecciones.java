
package Reproductor;

import java.io.*;
import java.util.NoSuchElementException;
import java.util.Scanner;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.sound.midi.InvalidMidiDataException;
import javax.sound.midi.MidiUnavailableException;
import javax.swing.JOptionPane;
import Song.Song;

/**
 *
 * @author david
 */
public class Selecciones {
    
    public void ReproducirCancion() throws InvalidMidiDataException, MidiUnavailableException{
        
        boolean Bandera=false;
        Song Rep= new Song(80);
        int seleccion;
        int uno=1;
        int dos=2;
        int tres=3;
   
        while(Bandera==false){
    seleccion=Integer.parseInt(JOptionPane.showInputDialog("Por favor  digite el numero de la opcion que desea:\n Por Ejemplo:  1\n 1-Reproducir Archivo\n 2- Modificar Archivo\n 3- Salir"));
  
      
     if (seleccion== uno && Bandera==false){
         
         try{     
        String selec=JOptionPane.showInputDialog("Por favor escriba la Ruta del archivo:");
        File ruta=new File(selec);
        
        if (ruta.exists()){
       
            FileReader leer=new FileReader (ruta.getAbsolutePath());
            BufferedReader buffering = new BufferedReader(leer);
            LineNumberReader Rl= new LineNumberReader(buffering);

                     Rep.setTempo(Integer.parseInt(Rl.readLine()));  
                     Rep.setInstrument(Rl.readLine(), 0);
                    
            String lineas="";
            
            while (lineas!=null){
                        int nota, pos, pul, vol;
                        lineas= Rl.readLine();
                        
                     Scanner sc=new Scanner (lineas);
                        nota=sc.nextInt();
                        pos=sc.nextInt();
                        pul=sc.nextInt();
                        vol=sc.nextInt();
                    
                   Rep.addNote(nota,pos,pul,vol);
                   Rep.play();

              buffering.close();
            }
        }else{
            JOptionPane.showMessageDialog(null, "Error la Ruta no fue encontrada, ubique el archivo e intruduzcalo de manera correcta");
          Bandera=false;
         
        }
  
         } catch(IOException | NoSuchElementException | NullPointerException e ){} 
     

     }else if(seleccion==dos && Bandera==false){
              
                
      try{     
        String selec=JOptionPane.showInputDialog("Por favor escriba la Ruta del archivo:");
       
        File ruta =new File(selec);
       
        if (ruta.exists()){
            FileWriter Editando=new FileWriter(ruta.getAbsolutePath(), true);
            String slc=JOptionPane.showInputDialog("por favor digite los Valores de Las Notas:\n Ejemplo: 12 129 8 64");
            
            Editando.write("\n");
            Editando.write(slc);
            JOptionPane.showMessageDialog(null, "las notas se han agregado con exito");
             Editando.close();
             Bandera=false;
        }else{
            JOptionPane.showMessageDialog(null, "Error la Ruta no fue encontrada, ubique el archivo e introduzcalo correctamente");
          Bandera=false;
            
        }
       
      }catch(IOException r ){} 
       catch (NumberFormatException r){}
    
    }else if(seleccion==tres && Bandera==false){
        JOptionPane.showMessageDialog(null, "El programa se ha finalizado con exito");
       System.exit(0);
       Bandera=true;
    }
   
        } 
  }
}
