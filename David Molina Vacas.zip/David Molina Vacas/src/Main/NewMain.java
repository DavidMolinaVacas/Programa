
package Main;

import Reproductor.Selecciones;
import javax.sound.midi.InvalidMidiDataException;
import javax.sound.midi.MidiUnavailableException;

/**
 *
 * @author david
 */
public class NewMain {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws InvalidMidiDataException, MidiUnavailableException {
        
        
        Selecciones usuario=new Selecciones();
        usuario.ReproducirCancion();
        
    }
    
}
