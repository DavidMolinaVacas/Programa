
package Song;

import javax.sound.midi.InvalidMidiDataException;
import javax.sound.midi.MetaEventListener;
import javax.sound.midi.MetaMessage;
import javax.sound.midi.MidiEvent;
import javax.sound.midi.MidiSystem;
import javax.sound.midi.MidiUnavailableException;
import javax.sound.midi.Sequence;
import javax.sound.midi.Sequencer;
import javax.sound.midi.ShortMessage;
import javax.sound.midi.Track;

/**
 *
 * @author david
 */
public final class Song {
    
     private final Sequencer sequencer;
    private final Sequence sequence;
    private final Track track;
    private String Instrumento;
    private int bpm;
     
    /*
     * Agrega una nota en la posición (pulso) indicada, con una duración y una intensidad de volumen concretos.
     */
    public void addNote(int note, long pos, long duration, int volume) throws InvalidMidiDataException{
 
        if (pos < 1) {
            throw new InvalidMidiDataException();
        }

        ShortMessage on = new ShortMessage(ShortMessage.NOTE_ON, 0, note, volume);
        ShortMessage off = new ShortMessage(ShortMessage.NOTE_OFF, 0, note, volume);

        track.add(new MidiEvent(on, pos));
        track.add(new MidiEvent(off, pos + duration));
    }

    /*
     * «bpm» son los pulsos por minuto, la velocidad de reproducción de la canción.
     */
    public Song(int bpm) throws InvalidMidiDataException, MidiUnavailableException {
        sequencer = MidiSystem.getSequencer( );
        sequence = new Sequence(Sequence.PPQ, 16);
        track = sequence.createTrack();

        setInstrument("celesta", 0);

        sequencer.open();  
        sequencer.setSequence(sequence);
        sequencer.addMetaEventListener(new MetaEventListener() {

            @Override
            public void meta(MetaMessage m) {

                if (m.getType( ) == 47) {

                    try {
                        Thread.sleep(2000);
                    } catch (InterruptedException e) {
                        System.out.println("meta >> " + e.getMessage());
                    }

                    System.exit(0);
                }

            }

        });

        if (bpm > 0 && bpm <= 240) {
            sequencer.setTempoInBPM(bpm);
        } else {
            sequencer.setTempoInBPM(120);
        }

    }

    public void setTempo(int bpm) {
        this.bpm=bpm;
        if (bpm > 0 && bpm <= 240) {
            sequencer.setTempoInBPM(bpm);
        }

    }

    /*
     * Este método establece el valor del instrumento de la canción.
     * «instrument» puede ser "bell", "strings", "celesta" o "piano". Si no, no lo cambia.
     */
    public void setInstrument(String instrument, int pos) throws InvalidMidiDataException {
           Instrumento=instrument;
        switch (instrument) {
            case "bell":
                track.add(new MidiEvent(new ShortMessage(ShortMessage.PROGRAM_CHANGE, 0, 14, 0), pos));
                break;
            case "strings":
                track.add(new MidiEvent(new ShortMessage(ShortMessage.PROGRAM_CHANGE, 0, 49, 0), pos));
                break;
            case "piano":
                track.add(new MidiEvent(new ShortMessage(ShortMessage.PROGRAM_CHANGE, 0, 1, 0), pos));
                break;
            case "celesta":
                track.add(new MidiEvent(new ShortMessage(ShortMessage.PROGRAM_CHANGE, 0, 9, 0), pos));
                break;
            default:
                System.out.println("setInstrument >> instrumento desconocido");
        }

    }

    public String getInstrumento() {
        return Instrumento;
    }

    public int getBpm() {
        return bpm;
    }
    

    public void play() {
        sequencer.start();
    }

}
